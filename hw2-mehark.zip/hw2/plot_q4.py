import os
import re
import numpy as np
import matplotlib.pyplot as plt
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

DATA_DIR = 'data'
METRIC = 'Eval_AverageReturn'

fig, ax = plt.subplots(figsize=(8, 5))

seen = {}
for d in sorted(os.listdir(DATA_DIR)):
    if not d.startswith('q4_') or d.endswith('.log'):
        continue
    if '_rtg' not in d or '_nnbaseline' not in d:
        continue
    m = re.search(r'_b(\d+)_lr([\d.]+)', d)
    if not m:
        continue
    b, lr = int(m.group(1)), float(m.group(2))
    label = 'b=%d, lr=%s' % (b, lr)
    if label in seen:
        continue  # keep first run only

    ea = EventAccumulator(os.path.join(DATA_DIR, d))
    ea.Reload()
    if METRIC not in ea.Tags().get('scalars', []):
        continue

    evs = ea.Scalars(METRIC)
    steps = np.array([e.step for e in evs])
    values = np.array([e.value for e in evs])

    seen[label] = True
    ax.plot(steps, values, label=label)

ax.set_xlabel('Iteration')
ax.set_ylabel(METRIC)
ax.set_title('Q4: HalfCheetah-v4 Sweep (RTG + NN Baseline)')
ax.legend(fontsize=9)
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('fig_q4.png', dpi=150, bbox_inches='tight')
print('Saved fig_q4.png')
plt.show()
